HEADER_LOCK = [
    "extractseqno","prod","source-desc-name","attributegrp",
    "descrip1","descrip2","descrip3","lookupnm","user24","rowpointer"
]
