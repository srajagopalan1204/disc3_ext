See the Specification (+Appendix Runbook) docx for policy details.
