# Update Description 3 (SAAMM + Pricing)

Builds a searchable `descrip3` with schema lock (only `descrip3` changes).
Inputs: SAAMM (primary), Pricing (secondary). PO removed.
See `docs/` for Spec + Runbook. Use `scripts/run_line.ps1` to run.
